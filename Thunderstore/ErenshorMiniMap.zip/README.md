# Mini Map

Adds a mini-map to the game that tracks vendors, mobs, players, and mining nodes.

## Installation
- Install [BepInEx Mod Pack](https://thunderstore.io/package/bbepis/BepInExPack/)
- Download the latest [release]()
- Extract the mod into *Erenshor\BepInEx\plugins* folder